#!/usr/bin/env bash
# Full analysis pipeline for AZ-SRV-01.img. Read-only: the image is never mounted.
set -euo pipefail
cd "$(dirname "$0")/.."

IMG="lab/AZ-SRV-01.img"
[ -f "$IMG" ] || { echo "Image missing. Run: python3 lab/build_evidence.py"; exit 1; }

mkdir -p analysis evidence

echo "[1/5] filesystem metadata"
fsstat -f ext4 "$IMG" > analysis/01_fsstat.txt

echo "[2/5] inode tree"
fls -f ext4 -r -p "$IMG" > analysis/02_fls.txt

echo "[3/5] body file"
fls -f ext4 -r -m / "$IMG" > analysis/03_bodyfile.txt

echo "[4/5] MACB timeline"
mactime -b analysis/03_bodyfile.txt -d 2>/dev/null > analysis/04_timeline.csv

echo "[5/5] artifact recovery by inode"
recover () { # path, output name
  ino=$(grep -F -m1 "$1" analysis/02_fls.txt | sed 's/^[^ ]* \([0-9]*\):.*/\1/')
  [ -n "$ino" ] || { echo "  ! not found: $1"; return; }
  icat -f ext4 "$IMG" "$ino" > "evidence/$2.recovered"
  echo "  $1  -> inode $ino  ($(wc -c < "evidence/$2.recovered") bytes)"
}
recover "var/www/html/uploads/.cache.php"        webshell_cache.php
recover "var/spool/cron/crontabs/www-data"       cron_www-data
recover "home/deploy/.bash_history"              bash_history_deploy
recover "home/deploy/.ssh/authorized_keys"       authorized_keys_deploy
recover "etc/sudoers.d/deploy"                   sudoers_deploy
recover "etc/passwd"                             etc_passwd
recover "var/log/apache2/access.log"             access_log
recover "var/log/auth.log"                       auth_log

sha256sum evidence/*.recovered > evidence/HASHES.txt
echo
echo "Done. Timeline rows: $(($(wc -l < analysis/04_timeline.csv) - 1))"
echo "Evidence hashes: evidence/HASHES.txt"
